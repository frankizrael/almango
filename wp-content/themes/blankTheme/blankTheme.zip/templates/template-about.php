<?php /* Template Name: about */
set_query_var('ENTRY', 'aboutt');
get_header();
?>

<?php get_footer();