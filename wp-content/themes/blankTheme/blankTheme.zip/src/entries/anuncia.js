import "../scss/anuncia.scss";
$('header').addClass('active2');