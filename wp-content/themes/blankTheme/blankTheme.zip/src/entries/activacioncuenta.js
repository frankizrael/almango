import "../scss/activacioncuenta.scss";
$('header').addClass('active2');
