import "../scss/terminosycondiciones.scss";
$('header').addClass('active2');

