import "../scss/passwordolvidada.scss";
$('header').addClass('active2');