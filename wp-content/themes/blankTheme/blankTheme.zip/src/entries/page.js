import '../scss/page.scss';
$('header').addClass('active2');