import "../scss/nosotros.scss";
$('header').addClass('active2');