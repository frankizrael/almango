import "../scss/financiamiento.scss";
$('header').addClass('active2');