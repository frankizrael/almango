<div id="compare-primary" class="sidebar">
    <?php dynamic_sidebar( 'compare' ); ?>
</div>